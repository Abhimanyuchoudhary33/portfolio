<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>update</title>

    <link rel="stylesheet" href="css/templatemo_style.css">
</head>
<body>





    <form action="" method="POST">
         

<?php
     include("connection2.php"); 

     $id = $_GET['id'];

     $selectquery = "select * from reservation where id=$id";
     $query = mysqli_query($conn,$selectquery);

     $result = mysqli_fetch_assoc($query);
     
     if(isset($_POST['submit']))
     {
         $id=$_POST['id'];
         $nm=$_POST['name'];
         $em=$_POST['value'];
         $pass=$_POST['date'];
         $updatequery = "update reservation set id='$id',  name='$nm', value='$em', date='$pass' where id=$id" ;
         $finalresult = mysqli_query($conn,$updatequery);
         if($finalresult){
             echo "updated successfully !";
         }
         else{
             echo "no updated";
         }
     }
 ?>
    
        id:<input type="number" name="id" value="<?php  echo $result['id']; ?>">
        name:<input type="text" name="name" value="<?php  echo $result['name']; ?>">
        value:<input type="text" name="value" value="<?php  echo $result['value']; ?>">
        massage:<input type="date" name="date" value="<?php  echo $result['date']; ?>">
        <input type="submit" name="submit" value="update">
        <li>
        <a href="select2.php">checklogin-form</a>
        </li>
        
    </form>

    
</body>
</html>