<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>select-operation</title>

    <!-- <link rel="stylesheet" href="css/templatemo_style.css"> -->

    <!-- <link rel="stylesheet" href="css/bootstrap.css"> -->
    <!-- <link rel="stylesheet" href="css/font-awesome.css"> -->
    <!-- <link rel="stylesheet" href="css/templatemo_style.css"> -->
    <!-- <link rel="stylesheet" href="css/templatemo_misc.css"> -->
    <!-- <link rel="stylesheet" href="css/flexslider.css"> -->
    <!-- <link rel="stylesheet" href="css/testimonails-slider.css"> -->

    <!-- <script src="js/vendor/modernizr-2.6.1-respond-1.1.0.min.js"></script> -->
    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/react-dom/18.3.0-next-9fcaf88d5-20220801/umd/react-dom.production.min.js"> -->
    
    <!-- <link rel="stylesheet" -->
        <!-- href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" /> -->
</head>
<body>

    <h1>All Operations</h1>

    
        
        
  <!-- <thead class="thead-dark">
 
    <tr>
      <th scope="col">#</th>
      <th scope="col">name</th>
      <th scope="col">email</th>
      <th scope="col">password</th>
    </tr>
  </thead> -->
  <!-- <tbody>
    <tr>
      <th scope="row">1</th>
      <td>Mark</td>
      <td>Otto</td>
      <td>@mdo</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Jacob</td>
      <td>Thornton</td>
      <td>@fat</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Larry</td>
      <td>the Bird</td>
      <td>@twitter</td>
    </tr>
  </tbody>
</table> -->

<table class="table">
  <thead class="thead-light">
    <tr>
      <th scope="col">id</th>
      <th scope="col">Name</th>
      <th scope="col">Email</th>
      <th scope="col">massage</th>
      <th colspan="2">operations</th>
      
    </tr>
  </thead>
  <tbody>
<?php
include "connection.php";

$selectquery = "select * from contact";
$query = mysqli_query($con,$selectquery);

while($result = mysqli_fetch_assoc($query)){


?>

    <tr>
      <!-- <th scope="row">1</th>
 -->  <td><?php echo $result['id']; ?> </td>
      <td><?php  echo $result['name']; ?> </td>
      <td><?php  echo $result['email']; ?> </td>
      <td><?php  echo $result['massage']; ?> </td>
      <td><button class="btn-danger btn"> <a href="update.php?id=<?php echo $result['id'] ?>"  class="text-white">update.php</a> </button> </td>
      <td><button class="btn-primary btn"> <a href="delete.php?id=<?php echo $result['id'] ?>" class="text-white">delete.php</a> </button>  </td>
      
    </tr>
<?php
    }
    ?>
  </tbody>
   

    


</body>
</html>