<?php
$servername="localhost";
$username="root";
$password="";
$dbname="dashboard";

$conn=mysqli_connect($servername,$username,$password,$dbname);

if($conn){
    // echo "database is okk";
}
else{
    echo "database is not okk";
}
?>