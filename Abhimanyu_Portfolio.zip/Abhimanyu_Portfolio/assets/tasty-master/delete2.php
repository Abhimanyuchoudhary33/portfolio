<?php

include "connection2.php";

$id = $_GET['id'];

$deletequery = "delete  from reservation where id =$id";
$query = mysqli_query($conn,$deletequery);

if($query){
	echo "row deleted!";
}




else{

	echo "no delete";
}


?>
<?php 

header('location:select2.php');
?>